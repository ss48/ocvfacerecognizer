# Contributors #

This file contains the list of people involved in the development
of facerec along its history. The purpose of this file is to 
encourage the participation in the project.

There is nothing like a minimal contribution, so if you have 
contributed to the library, then feel free to add your 
name to the list:

* Philipp Wagner [bytefish[at]gmx[dot]de]
* Florian Lier [flier[at]techfak.uni-bielefeld.de]
* Norman Köster [nkoester[at]techfak.uni-bielefeld.de]